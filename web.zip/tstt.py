
user = 'The purpose of our lives is to be happy'

users = user.split()

for i in users:
  print(ord(str(len(i))), end=",")